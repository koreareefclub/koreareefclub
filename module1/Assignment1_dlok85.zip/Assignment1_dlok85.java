package module1;

public class Assignment1_dlok85 {
	public static void main(String[] args) {
		System.out.println("MM   MM Y   Y      J     A     V     V     A");
		System.out.println("M MMM M  Y Y       J    A A     V   V     A A");
		System.out.println("M  M  M   Y    J   J   AAAAA     V V     AAAAA");
		System.out.println("M     M   Y     J J   A     A     V     A     A");
		System.out.println("");
		System.out.println("");
		System.out.println("U     U SSSSS  IIIIIII N    N  GGGG");
		System.out.println("U     U S         I    NN   N  G");
		System.out.println("U     U  SS       I    N N  N  G GGGG");
		System.out.println(" U   U     S      I    N  N N  G    G");
		System.out.println("  UUU    SSSS  IIIIIII N   NN  GGGGGG");
		System.out.println("");
		System.out.println("");
		System.out.println("TTTTTTT EEEEEE RRRRR  MM   MM IIIIIII N     N    A     L");
		System.out.println("   T    E      R    R M MMM M    I    NN    N   A A    L");
		System.out.println("   T    EEEEE  RRRRRR M  M  M    I    N N   N  AAAAA   L");
		System.out.println("   T    E      R    R M  M  M    I    N  N  N A     A  L");
		System.out.println("   T    EEEEEE R    R M     M  IIIII  N   N N A      A LLLLLL");
	}
}
